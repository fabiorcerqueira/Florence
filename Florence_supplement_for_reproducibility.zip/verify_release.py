from pathlib import Path
import pandas as pd
import hashlib
root=Path(__file__).resolve().parent
files=['architecture_predictions.csv','prompt_predictions.csv','ensemble_predictions.csv','human_consensus_aggregated.csv']
for name in files:
 p=root/'data'/name
 df=pd.read_csv(p)
 print(name, 'rows=',len(df),'columns=',len(df.columns),'sha256=',hashlib.sha256(p.read_bytes()).hexdigest())
 assert len(df)>0
 print('  ID candidates:',[x for x in df.columns if 'image' in x.lower() or x.lower() in ('id','image_number')])
print('Input file integrity: OK. This is not an independent GPU inference reproduction.')
