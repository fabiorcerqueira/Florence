#!/usr/bin/env python3
"""FPD-181 supplemental analyses. Fixed RNG seed; no inference is performed."""
from pathlib import Path
from itertools import combinations
import numpy as np
import pandas as pd
from scipy.stats import binomtest, spearmanr
BASE=Path(__file__).resolve().parent
D=BASE/'data'; O=BASE/'recomputed'; O.mkdir(exist_ok=True)
SEED=20261115; B=10000; NPERM=10000
rng=np.random.default_rng(SEED)
a=pd.read_csv(D/'architecture_predictions.csv').sort_values('image_number').reset_index(drop=True)
p=pd.read_csv(D/'prompt_predictions.csv').sort_values(['architecture','image_number']).reset_index(drop=True)
e=pd.read_csv(D/'ensemble_predictions.csv').sort_values('image_number').reset_index(drop=True)
h=pd.read_csv(D/'human_consensus_aggregated.csv').sort_values('image_number').reset_index(drop=True)
ids=set(a.image_number); excluded={95,97,140,155,182,185,186,189}
assert len(a)==len(e)==len(h)==181 and len(ids)==181 and not(ids&excluded)
assert set(e.image_number)==set(h.image_number)==ids
assert len(p)==543 and all(set(g.image_number)==ids for _,g in p.groupby('architecture'))
models=['Likelihood','Qwen','Llama_restricted','BLIP2','Llama_original','CLIP','SigLIP','SigLIP2']
strategies=['binary','affective','B_experiential','C_observable']
ens=['SigLIP2_Qwen_Likelihood','CLIP_SigLIP_Qwen','SigLIP_SigLIP2_Qwen']
def accuracy(y,pred):
 return np.mean(np.asarray(y)==np.asarray(pred))
def ci(correct):
 x=np.asarray(correct,dtype=float); idx=rng.integers(0,len(x),size=(B,len(x)))
 return np.quantile(x[idx].mean(axis=1),[.025,.975])
def holm(df, pcol='p_raw'):
 df=df.sort_values(pcol).reset_index(drop=True)
 adj=np.maximum.accumulate(np.minimum(1.,df[pcol].to_numpy()*(len(df)-np.arange(len(df)))))
 df['p_holm']=adj;df['significant_05']=adj<.05
 return df
def mcnemar(x,y):
 x=np.asarray(x,dtype=bool);y=np.asarray(y,dtype=bool)
 b=int((x&~y).sum());c=int((~x&y).sum());n=b+c
 return b,c,float(binomtest(min(b,c),n,.5).pvalue) if n else 1.
rows=[]
for m in models:
 y=a[m+'_truth'].to_numpy(); pred=a[m+'_prediction'].to_numpy();ok=(y==pred)
 lo,hi=ci(ok);rows.append(dict(model=m,n=len(ok),correct=int(ok.sum()),accuracy=ok.mean(),ci_low=lo,ci_high=hi))
pd.DataFrame(rows).to_csv(O/'architecture_bootstrap_95ci.csv',index=False)
rows=[]
for name,g in p.groupby('architecture'):
 for s in strategies:
  ok=(g.true_label.to_numpy()==g[s].to_numpy());lo,hi=ci(ok)
  rows.append(dict(architecture=name,prompt=s,n=len(ok),correct=int(ok.sum()),accuracy=ok.mean(),ci_low=lo,ci_high=hi))
pd.DataFrame(rows).to_csv(O/'prompt_bootstrap_95ci.csv',index=False)
rows=[]
for m in ens:
 ok=(e.true_label.to_numpy()==e[m].to_numpy());lo,hi=ci(ok)
 rows.append(dict(ensemble=m,n=len(ok),correct=int(ok.sum()),accuracy=ok.mean(),ci_low=lo,ci_high=hi))
pd.DataFrame(rows).to_csv(O/'ensemble_bootstrap_95ci.csv',index=False)
rows=[]
for x,y in combinations(models,2):
 cx=a[x+'_truth'].to_numpy()==a[x+'_prediction'].to_numpy();cy=a[y+'_truth'].to_numpy()==a[y+'_prediction'].to_numpy()
 b,c,pval=mcnemar(cx,cy);rows.append(dict(model_a=x,model_b=y,a_only_correct=b,b_only_correct=c,delta_accuracy=cx.mean()-cy.mean(),p_raw=pval))
holm(pd.DataFrame(rows)).to_csv(O/'architecture_all_28_mcnemar_holm.csv',index=False)
rows=[]
for arch,g in p.groupby('architecture'):
 for s1,s2 in combinations(strategies,2):
  x=(g.true_label==g[s1]).to_numpy();y=(g.true_label==g[s2]).to_numpy();b,c,pval=mcnemar(x,y)
  rows.append(dict(architecture=arch,prompt_a=s1,prompt_b=s2,a_only_correct=b,b_only_correct=c,delta_accuracy=x.mean()-y.mean(),p_raw=pval))
# correction separately for each architecture, six tests each
pd.concat([holm(g) for _,g in pd.DataFrame(rows).groupby('architecture')],ignore_index=True).to_csv(O/'prompt_mcnemar_holm.csv',index=False)
rows=[]
q=(e.true_label==e.Qwen).to_numpy()
for m in ens:
 x=(e.true_label==e[m]).to_numpy();b,c,pval=mcnemar(x,q)
 rows.append(dict(ensemble=m,comparator='Qwen',ensemble_only_correct=b,qwen_only_correct=c,delta_accuracy=x.mean()-q.mean(),p_raw=pval))
holm(pd.DataFrame(rows)).to_csv(O/'ensemble_mcnemar_holm.csv',index=False)
# Error association: rank correlation with human uncertainty, permutation test of error assignments
rows=[]
hm={'human_disagreement':1-h.reference_agreement_fraction.to_numpy(dtype=float),
    'human_indeterminate_fraction':(h.n_indeterminate/h.n_human).to_numpy(dtype=float)}
for m in ens:
 err=(e.true_label.to_numpy()!=e[m].to_numpy()).astype(int)
 for name,v in hm.items():
  obs=float(spearmanr(err,v).statistic)
  if not np.isfinite(obs): raise ValueError('undefined correlation')
  # Permute errors, holding number of errors and human scores fixed
  more=0
  for _ in range(NPERM):
   val=float(spearmanr(rng.permutation(err),v).statistic)
   more+=abs(val)>=abs(obs)-1e-12
  rows.append(dict(ensemble=m,human_metric=name,n=len(err),errors=int(err.sum()),rho=obs,permutation_p=(more+1)/(NPERM+1)))
holm(pd.DataFrame(rows),'permutation_p').to_csv(O/'human_error_permutation_holm.csv',index=False)
# stable image-wise prompt agreement: all four predictions identical
rows=[]
for arch,g in p.groupby('architecture'):
 allsame=g[strategies].nunique(axis=1).eq(1)
 rows.append(dict(architecture=arch,n=len(g),all_four_agree=int(allsame.sum()),fraction_all_four_agree=allsame.mean()))
pd.DataFrame(rows).to_csv(O/'prompt_stability_simple.csv',index=False)
print('FPD-181: 181 images, all extended outputs generated, seed=',SEED)
