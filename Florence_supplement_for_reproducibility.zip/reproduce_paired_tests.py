import pandas as pd,itertools
from scipy.stats import binomtest
from statsmodels.stats.multitest import multipletests
from pathlib import Path
root=Path(__file__).resolve().parent
p=str(root/'data')+'/'
(root/'results').mkdir(exist_ok=True)
a=pd.read_csv(p+'architecture_predictions.csv');e=pd.read_csv(p+'ensemble_predictions.csv');q=pd.read_csv(p+'prompt_predictions.csv')
def calc(items):
 out=[]
 for x,y in items:
  cx,cy=x[1],y[1];b=int((cx&~cy).sum());c=int((~cx&cy).sum());pv=binomtest(min(b,c),b+c).pvalue if b+c else 1
  out.append([x[0],y[0],b,c,pv,100*(cx.mean()-cy.mean())])
 d=pd.DataFrame(out,columns=['a','b','a_only','b_only','p','delta_pp']);d['holm']=multipletests(d.p,method='holm')[1];return d
rep=['CLIP','SigLIP','SigLIP2','BLIP2','Qwen','Likelihood']; cond={m:(a[m+'_correct'].astype(bool)) for m in rep};d=calc([( (x,cond[x]),(y,cond[y])) for x,y in itertools.combinations(rep,2)]);print('15 PAIRS');print(d[d.holm<.05].to_string(index=False));print('BLIP2 vs Likelihood',d.query("a=='BLIP2' and b=='Likelihood'").to_string(index=False));d.to_csv(root/'results'/'visapp_15_tests_verified.csv',index=False)
ens=['CLIP_SigLIP_Qwen','SigLIP2_Qwen_Likelihood','SigLIP_SigLIP2_Qwen'];single=['Qwen','Likelihood','SigLIP','SigLIP2'];pred={m:(e[m]==e.true_label) for m in ens+single};d=calc([((x,pred[x]),(y,pred[y])) for x in ens for y in single]);print('12 ensemble p Qwen');print(d.query("b=='Qwen'").to_string(index=False));d.to_csv(root/'results'/'visapp_12_ensemble_tests_verified.csv',index=False)
rows=[]
for m,g in q.groupby('architecture'):
 for alt in ['binary','B_experiential','C_observable']:
  x=(g.affective==g.true_label);y=(g[alt]==g.true_label);rows.append(((m+' affective',x.reset_index(drop=True)),(m+' '+alt,y.reset_index(drop=True))))
d=calc(rows);print('9 prompt');print(d.to_string(index=False));d.to_csv(root/'results'/'visapp_9_prompt_tests_verified.csv',index=False)
