"""Reproduce the Gain, 95% CI and Holm p columns of the paper's prompt tables.

Table 5 (contrastive models): original affective set minus each alternative
(binary, experiential, observable) for CLIP, SigLIP and SigLIP2; Holm over 9.
Table 6 (generative models): affective prompt minus each alternative prompt
(direct, comparative) for Qwen, Llama (unconstrained) and BLIP-2; Holm over 5.

Gain: difference in accuracy, in percentage points (invalid answers count as errors).
95% CI: paired percentile bootstrap over the 181 images, 20,000 resamples,
seed 20261115; the same resampling matrix is used for every comparison.
Not adjusted for multiplicity.
Holm p: exact McNemar (binomial) test on the discordant images, Holm-adjusted
within each table.

Usage: python reproduce_prompt_gains.py   (requires numpy, pandas, scipy)
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import binomtest

SEED, B, N = 20261115, 20000, 181
D = Path(__file__).resolve().parent / "data"
IDX = np.random.default_rng(SEED).integers(0, N, size=(B, N))


def compare(ref_correct, alt_correct):
    ref = np.asarray(ref_correct, dtype=int)
    alt = np.asarray(alt_correct, dtype=int)
    diff = ref - alt
    lo, hi = np.percentile(diff[IDX].mean(axis=1) * 100, [2.5, 97.5])
    n10, n01 = int(((ref == 1) & (alt == 0)).sum()), int(((ref == 0) & (alt == 1)).sum())
    p = binomtest(n10, n10 + n01, 0.5).pvalue if n10 + n01 else 1.0
    return 100 * diff.mean(), lo, hi, p


def holm(df):
    order = df["p_exact"].sort_values().index
    running, adjusted = 0.0, {}
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (len(df) - rank) * df.loc[i, "p_exact"]))
        adjusted[i] = running
    df["p_holm"] = pd.Series(adjusted)
    return df


# ---- Table 5: contrastive models ----
prompts = pd.read_csv(D / "prompt_predictions.csv")
rows = []
for arch, g in prompts.groupby("architecture", sort=False):
    g = g.sort_values("image_number")
    assert len(g) == N
    y = g["true_label"].to_numpy()
    ref = g["affective"].to_numpy() == y
    for alt, name in [("binary", "Binary"), ("B_experiential", "Affective (experiential)"),
                      ("C_observable", "Affective (observable)")]:
        gain, lo, hi, p = compare(ref, g[alt].to_numpy() == y)
        rows.append({"model": arch, "alternative": name, "gain_pp": gain,
                     "ci_low_pp": lo, "ci_high_pp": hi, "p_exact": p})
t5 = holm(pd.DataFrame(rows))

# ---- Table 6: generative models ----
qwen = pd.read_csv(D / "qwen25_vl3b_prompt_predictions.csv")
llama = pd.read_csv(D / "llama32_vision11b_prompt_predictions.csv")
blip = pd.read_csv(D / "blip2_prompt_predictions.csv").rename(columns={"valid_response": "valid"})
blip["protocol"] = blip["protocol"].map({"10B_binary_comparative": "B_comparative",
                                          "10C_affective": "C_affective"})
rows = []
for name, df in [("Qwen2.5-VL-3B", qwen), ("Llama 3.2 (unconstrained)", llama), ("BLIP-2", blip)]:
    correct = {}
    for proto, g in df.groupby("protocol"):
        g = g.sort_values("image_number")
        assert len(g) == N
        correct[proto] = (g["valid"].astype(bool) & (g["predicted_label"] == g["true_label"])).to_numpy()
    for alt, label in [("A_direct", "Direct (yes/no)"), ("B_comparative", "Comparative")]:
        if alt in correct:
            gain, lo, hi, p = compare(correct["C_affective"], correct[alt])
            rows.append({"model": name, "alternative": label, "gain_pp": gain,
                         "ci_low_pp": lo, "ci_high_pp": hi, "p_exact": p})
t6 = holm(pd.DataFrame(rows))

pd.set_option("display.width", 200)
fmt = {"gain_pp": "{:+.2f}".format, "ci_low_pp": "{:.2f}".format, "ci_high_pp": "{:.2f}".format,
       "p_exact": "{:.3g}".format, "p_holm": "{:.2g}".format}
print("Table 5 (contrastive; Holm over 9)")
print(t5.to_string(index=False, formatters=fmt))
print("\nTable 6 (generative; Holm over 5)")
print(t6.to_string(index=False, formatters=fmt))
t5.to_csv("prompt_gains_contrastive.csv", index=False)
t6.to_csv("prompt_gains_generative.csv", index=False)

# ---- Prediction stability across the three six-category wordings ----
# Stable image: the Pain/NoPain decision is the same under the original,
# experiential and observable affective sets. A stable decision can still be wrong.
print("\nStability across the three six-category wordings (contrastive models)")
for arch, g in prompts.groupby("architecture", sort=False):
    decisions = g[["affective", "B_experiential", "C_observable"]]
    stable = decisions.nunique(axis=1) == 1
    wrong = stable & (g["affective"] != g["true_label"])
    print(f"  {arch:8s} stable {int(stable.sum())}/{N} ({100 * stable.mean():.2f}%), "
          f"of which correct {int((stable & ~wrong).sum())} and wrong {int(wrong.sum())}")
