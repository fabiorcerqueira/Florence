"""Reproduce Table 6 (base prompt protocols for the generative models) from archived predictions.
Exact McNemar (binomial) tests, affective vs each alternative, Holm over the five comparisons.
Invalid responses count as errors for accuracy; sensitivity/specificity use valid predictions only.
Usage: python reproduce_generative_prompts.py  (requires pandas, scipy)"""
from pathlib import Path
import pandas as pd
from scipy.stats import binomtest

D = Path(__file__).resolve().parent / "data"
qwen = pd.read_csv(D / "qwen25_vl3b_prompt_predictions.csv")
llama = pd.read_csv(D / "llama32_vision11b_prompt_predictions.csv")
blip = pd.read_csv(D / "blip2_prompt_predictions.csv").rename(columns={"valid_response": "valid"})
blip["protocol"] = blip["protocol"].map({"10B_binary_comparative": "B_comparative", "10C_affective": "C_affective"})
ref = pd.read_csv(D / "human_consensus_aggregated.csv").set_index("image_number")

rows, correct = [], {}
for name, df in [("Qwen2.5-VL-3B", qwen), ("Llama 3.2 (original)", llama), ("BLIP-2", blip)]:
    for proto, g in df.groupby("protocol"):
        g = g.set_index("image_number").sort_index()
        assert len(g) == 181 and set(g.index) == set(ref.index), "image set mismatch"
        assert (g["true_label"] == ref.loc[g.index, "true_label"]).all(), "label mismatch"
        v = g["valid"].astype(bool)
        c = v & (g["predicted_label"] == g["true_label"])
        correct[(name, proto)] = c
        gv = g[v]
        pos, neg = gv["true_label"] == 1, gv["true_label"] == 0
        rows.append({"model": name, "protocol": proto, "correct": int(c.sum()), "invalid": int((~v).sum()),
                     "accuracy_pct": 100 * c.mean(),
                     "sensitivity_pct": 100 * (gv.loc[pos, "predicted_label"] == 1).mean(),
                     "specificity_pct": 100 * (gv.loc[neg, "predicted_label"] == 0).mean()})
desc = pd.DataFrame(rows)

tests = []
for (name, proto), c in correct.items():
    if proto == "C_affective":
        continue
    a = correct[(name, "C_affective")].values
    o = c.values
    n10, n01 = int((a & ~o).sum()), int((~a & o).sum())
    p = binomtest(n10, n10 + n01, 0.5).pvalue if n10 + n01 else 1.0
    tests.append({"model": name, "alternative": proto, "gain_pp": 100 * (a.mean() - o.mean()),
                  "affective_only_correct": n10, "alternative_only_correct": n01, "p_exact": p})
t = pd.DataFrame(tests).sort_values("p_exact").reset_index(drop=True)
m, running, adj = len(t), 0.0, []
for i, p in enumerate(t["p_exact"]):
    running = max(running, min(1.0, (m - i) * p))
    adj.append(running)
t["p_holm"] = adj

pd.set_option("display.width", 200)
print(desc.round(2).to_string(index=False)); print()
print(t.to_string(index=False, float_format=lambda x: f"{x:.4g}"))
desc.to_csv("generative_prompt_protocols.csv", index=False)
t.to_csv("generative_prompt_mcnemar_holm.csv", index=False)

# ---------------------------------------------------------------------------
# Category-to-binary mapping (Discussion): effect of also counting "sadness"
# as Pain in Qwen's affective answers. Same predictions, different mapping rule.
# ---------------------------------------------------------------------------
qa = qwen[qwen["protocol"] == "C_affective"]
y = qa["true_label"]
print("\nQwen affective prompt: effect of the category-to-binary mapping")
for label, pain_categories in [("pain only (used in the paper)", {"pain"}),
                               ("pain + sadness", {"pain", "sadness"})]:
    pred = qa["parsed_category"].isin(pain_categories).astype(int)
    missed = int(((pred == 0) & (y == 1)).sum())
    false_alarms = int(((pred == 1) & (y == 0)).sum())
    print(f"  {label:30s} accuracy {100 * (pred == y).mean():.2f}%  "
          f"missed Pain images {missed}  false alarms {false_alarms}")
