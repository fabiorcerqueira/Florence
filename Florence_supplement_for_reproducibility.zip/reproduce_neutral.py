"""Reproduce the supplementary 'neutral' check (paper, Section 6.2).

Compares each model with and without a 'neutral' category, from archived
predictions only (no images, no GPU). The predictions with 'neutral' were
produced by florence_neutral_experiment.ipynb; those without 'neutral'
are the paper's conditions.

Requirements: pandas, numpy, scipy.   Run: python reproduce_neutral.py
"""
from pathlib import Path
import pandas as pd

SUPP = Path(__file__).resolve().parent / "data"
OUT = SUPP / "neutral"

import numpy as np
from scipy.stats import binomtest


def holm(pvalues):
    p = np.asarray(pvalues, dtype=float)
    order = np.argsort(p)
    adjusted = np.empty_like(p)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, (len(p) - rank) * p[i])
        adjusted[i] = min(1.0, running)
    return adjusted

fpd = pd.read_csv(SUPP / "human_consensus_aggregated.csv")[
    ["image_number", "true_label"]].astype(int)
assert len(fpd) == 181
human = pd.read_csv(SUPP / "human_consensus_aggregated.csv")
neutral_images = set(human.loc[
    human["image"].str.contains("/neutral/"), "image_number"])

pairs = {}   # name -> (without neutral, with neutral) DataFrames:
             # image_number, predicted_label, valid, category

# ---------- contrastive ----------
f = OUT / "contrastive_neutral_predictions.csv"
if f.exists():
    c = pd.read_csv(f)
    supp = pd.read_csv(SUPP / "prompt_predictions.csv")
    for arch, g in c.groupby("architecture"):
        def take(strategy):
            d = g[g["strategy"] == strategy][
                ["image_number", "predicted_label", "predicted_class"]
            ].rename(columns={"predicted_class": "category"})
            d["valid"] = True
            return d
        base, new = take("affective"), take("affective_neutral")
        # Check that the rerun reproduces the paper's decisions
        s = supp[supp["architecture"] == arch][
            ["image_number", "affective"]]
        m = base.merge(s, on="image_number")
        diff = int((m["predicted_label"] != m["affective"]).sum())
        print(f"{arch}: 'affective' decisions differing from the paper: "
              f"{diff}/181")
        pairs[arch] = (base, new)
else:
    print("Contrastive file not found.")

# ---------- Qwen ----------
f = OUT / "qwen25_vl3b_neutral_predictions.csv"
if f.exists():
    q = pd.read_csv(SUPP / "qwen25_vl3b_prompt_predictions.csv")
    q = q[q["protocol"] == "C_affective"]
    def prep(d, cat_col):
        d = d.copy()
        d["valid"] = d["valid"].astype(str).str.lower() == "true"
        d["category"] = d[cat_col].fillna("INVALID")
        return d[["image_number", "predicted_label", "valid", "category"]]
    pairs["Qwen"] = (prep(q, "parsed_category"),
                     prep(pd.read_csv(f), "parsed_category"))
else:
    print("Qwen file not found.")

# ---------- Llama (constrained decoding) ----------
f = OUT / "llama32_vision11b_neutral_restricted_predictions.csv"
if f.exists():
    a = pd.read_csv(SUPP / "architecture_predictions.csv")
    base = pd.DataFrame({
        "image_number": a["image_number"],
        "predicted_label": a["Llama_restricted_prediction"],
        "valid": True, "category": np.nan})
    new = pd.read_csv(f).rename(
        columns={"restricted_category": "category"})
    new["valid"] = True
    pairs["Llama constr."] = (
        base, new[["image_number", "predicted_label", "valid",
                   "category"]])
else:
    print("Llama file not found.")

assert pairs, "No condition available."


def metrics(d):
    d = fpd.merge(d, on="image_number", validate="one_to_one")
    assert len(d) == 181
    ok = d["valid"] & (d["predicted_label"] == d["true_label"])
    v = d[d["valid"]]
    pain, nopain = v[v["true_label"] == 1], v[v["true_label"] == 0]
    return d.assign(ok=ok), {
        "acc": 100 * ok.mean(),
        "sens": 100 * (pain["predicted_label"] == 1).mean(),
        "spec": 100 * (nopain["predicted_label"] == 0).mean(),
        "invalid": int((~d["valid"]).sum()),
    }


rows, details = [], {}
for name, (base, new) in pairs.items():
    b, mb = metrics(base)
    n, mn = metrics(new)
    only_base = int((b["ok"] & ~n["ok"]).sum())   # correct only without neutral
    only_new = int((~b["ok"] & n["ok"]).sum())    # correct only with neutral
    k = only_base + only_new
    p = binomtest(only_new, k, 0.5).pvalue if k else 1.0
    neutral = n[n["category"] == "neutral"]
    rows.append({
        "model": name,
        "acc_without": round(mb["acc"], 2),
        "acc_with": round(mn["acc"], 2),
        "gain_pp": round(mn["acc"] - mb["acc"], 2),
        "sens_without": round(mb["sens"], 2),
        "sens_with": round(mn["sens"], 2),
        "spec_without": round(mb["spec"], 2),
        "spec_with": round(mn["spec"], 2),
        "invalid_without": mb["invalid"],
        "invalid_with": mn["invalid"],
        "worse_with": only_base,
        "better_with": only_new,
        "p_mcnemar": p,
        "neutral_on_Pain": int((neutral["true_label"] == 1).sum()),
        "neutral_on_NoPain": int((neutral["true_label"] == 0).sum()),
        "human_neutral_image_correct": "/".join(
            str(int(x)) for x in
            n.loc[n["image_number"].isin(neutral_images), "ok"]),
    })

table = pd.DataFrame(rows)
table["p_holm"] = holm(table["p_mcnemar"])
table.to_csv("neutral_comparison.csv", index=False)

pd.set_option("display.width", 200)
print("\n=== WITH AND WITHOUT THE NEUTRAL CATEGORY ===")
print(table[["model", "acc_without", "acc_with", "gain_pp",
             "p_mcnemar", "p_holm", "invalid_without",
             "invalid_with"]].to_string(index=False))
print("\nSensitivity / specificity on valid answers (%):")
print(table[["model", "sens_without", "sens_with", "spec_without",
             "spec_with"]].to_string(index=False))
print("\nImages whose correctness changes (worse_with = correct without "
      "neutral, wrong with it):")
print(table[["model", "worse_with", "better_with"]]
      .to_string(index=False))
print("\n'neutral' answers (on Pain images = missed pain):")
print(table[["model", "neutral_on_Pain", "neutral_on_NoPain"]]
      .to_string(index=False))
print(f"\nImages with a human 'neutral' majority: {sorted(neutral_images)}"
      " (1 = correct with neutral)")
print(table[["model", "human_neutral_image_correct"]]
      .to_string(index=False))
print("\nWritten: neutral_comparison.csv")
