#!/usr/bin/env python3
"""Recompute FPD-181 descriptive classification metrics and exact paired tests.
Dependencies: pandas, numpy, scipy. Run: python reproduce.py
Invalid responses count as incorrect for the headline accuracy.
"""
from pathlib import Path
from itertools import combinations
import pandas as pd
import numpy as np
from scipy.stats import binomtest
BASE=Path(__file__).resolve().parent
DATA=BASE/'data'; OUT=BASE/'recomputed';OUT.mkdir(exist_ok=True)
EXCLUDED={95,97,140,155,182,185,186,189}
IDS=set(a.image_number) if False else None
models=['Likelihood','Qwen','Llama_restricted','BLIP2','Llama_original','CLIP','SigLIP','SigLIP2']
a=pd.read_csv(DATA/'architecture_predictions.csv')
p=pd.read_csv(DATA/'prompt_predictions.csv')
e=pd.read_csv(DATA/'ensemble_predictions.csv')
h=pd.read_csv(DATA/'human_consensus_aggregated.csv')
IDS=set(a.image_number)
assert len(IDS)==181 and not (IDS & EXCLUDED)
for name,d in [('architecture',a),('prompts',p),('ensemble',e),('human',h)]:
 assert set(d.image_number)==IDS,(name,'IDs mismatch')
assert len(a)==len(e)==len(h)==181 and len(p)==543
assert p.groupby('architecture').image_number.nunique().eq(181).all()
def metric(y,pred):
 y=np.asarray(y,dtype=int); pred=pd.to_numeric(pd.Series(pred),errors='coerce').to_numpy()
 correct=(pred==y); tp=int(((y==1)&(pred==1)).sum());tn=int(((y==0)&(pred==0)).sum())
 fp=int(((y==0)&(pred==1)).sum());fn=int(((y==1)&(pred==0)).sum())
 invalid=int((~np.isin(pred,[0,1])).sum())
 return dict(n=len(y),correct=int(correct.sum()),accuracy=correct.mean(),TP=tp,TN=tn,FP=fp,FN=fn,invalid=invalid,
 sensitivity=tp/(y==1).sum(),specificity=tn/(y==0).sum(),precision=tp/(tp+fp) if tp+fp else np.nan,
 f1=2*tp/(2*tp+fp+fn+int(((y==1)&(~np.isin(pred,[0,1]))).sum())) if tp else 0)
rows=[]
for m in models:
 truth=a[m+'_truth'];pred=a[m+'_prediction'];rows.append(dict(model=m,**metric(truth,pred)))
pd.DataFrame(rows).to_csv(OUT/'architecture_metrics.csv',index=False)
rows=[]
for arch,g in p.groupby('architecture'):
 for strategy in ['binary','affective','B_experiential','C_observable']:
  rows.append(dict(model=arch,strategy=strategy,**metric(g.true_label,g[strategy])))
pd.DataFrame(rows).to_csv(OUT/'prompt_metrics.csv',index=False)
rows=[]
for m in ['SigLIP2_Qwen_Likelihood','CLIP_SigLIP_Qwen','SigLIP_SigLIP2_Qwen']:
 rows.append(dict(ensemble=m,**metric(e.true_label,e[m])))
pd.DataFrame(rows).to_csv(OUT/'ensemble_metrics.csv',index=False)
rows=[]
for m1,m2 in combinations(models,2):
 c1=(a[m1+'_prediction']==a[m1+'_truth']);c2=(a[m2+'_prediction']==a[m2+'_truth'])
 b=int((c1&~c2).sum());c=int((~c1&c2).sum());n=b+c
 rows.append(dict(model1=m1,model2=m2,b=b,c=c,p_exact=binomtest(min(b,c),n,0.5).pvalue if n else 1.0))
r=pd.DataFrame(rows).sort_values('p_exact').reset_index(drop=True);k=len(r)
r['p_holm']=[min(1.,max((k-j)*r.loc[j,'p_exact'] for j in range(i+1))) for i in range(k)]
r.to_csv(OUT/'architecture_mcnemar_28_holm.csv',index=False)
print('Validated 181 unique images; output:',OUT)
