# Florence — VISAPP 2027: reproducibility release (FPD-181)

## Scope
This archive reproduces **statistics from recorded image-level predictions**. It also includes the **original experimental notebook, as archived** (see the execution-map notes below) and an index of its code cells. It does **not** claim to have re-executed GPU inference or validated a fully fresh run.

## Public resources
- Florence application and original notebook: https://github.com/fabiorcerqueira/Florence
- Experimental notebook: https://github.com/fabiorcerqueira/Florence/blob/main/testing_models.ipynb
- Images and human assessments: https://github.com/fabiorcerqueira/pain_nopain_img_rep
- Google Forms generator: https://github.com/fabiorcerqueira/create_form_for_img_human_validation
- Original Colab: https://colab.research.google.com/drive/12OK7ZDLxFMfpVwEFjRC4cSfyXBJZWp0f?usp=sharing

## Dataset scope and provenance
FPD-181 includes 181 binary-labeled images (99 Pain; 82 No Pain). The original inference collection comprised 189 images; eight with inconclusive human labels (IDs 95, 97, 140, 155, 182, 185, 186, 189) were excluded from the *post-inference* binary evaluation. The excluded images were not removed based on model correctness. Keep this provenance note in supplementary methods.

## Recompute without GPU
From the extracted directory, install `pandas numpy scipy scikit-learn statsmodels` in an isolated Python environment, then run:

```bash
python verify_release.py
python reproduce.py
python reproduce_extended.py
python reproduce_generative_prompts.py   # Table 4: generative base prompts
```

Scripts are preserved from the previous supplement; their dependency versions and exact output equivalence should be validated in a fresh environment before archival release.

## Original inference notebook: execution map
`testing_models_original.ipynb` is an archival copy, **not a clean run-all notebook**. Some consolidation cells (for example, Experiments 25, 26B.2 and 26C.2) were edited after execution: their source code refers to 181 images and asserts the counts of the earlier 189-image run (e.g., 179 correct answers for Qwen), while their stored outputs come from that 189-image run, in which the eight inconclusive images were still included. Re-running these cells on the 181-image prediction files would fail at those assertions (Qwen has 171 correct answers on FPD-181). The published 181-image results are those recomputed by `reproduce.py`, `reproduce_extended.py` and `reproduce_generative_prompts.py` from the archived predictions, not the stored outputs of those cells. See `notebook_cell_inventory.csv` for cell positions, model IDs, CSV dependencies and global-state requirements. Important landmarks (zero-based code cell indices):

- 4: CLIP inference; 8: SigLIP2; 12: SigLIP; 20: semantic prompt variants
- 41: BLIP-2; 46–50: Qwen2.5-VL
- 61–63: Llama environment and model loading; 88: Llama candidate likelihood (Exp. 24B.3)
- 92: generative consolidation; 94: cross-architecture integration; 107–115: audits and editorial tables

Llama likelihood cell 88 explicitly requires preloaded `model` and `processor`, and CSVs `florence_exp24b_resolved_images.csv` and `llama32_vision11b_restricted_predictions.csv`. It uses 12 candidate sequences over six facial-expression categories, scoring candidate token log-probabilities. Running it independently requires reproducing the original model load and data preparation.

## Outstanding before claiming end-to-end reproducibility
1. Capture tested library versions and immutable model revisions (not just model IDs); notebook uses unpinned package installs.
2. Validate the fresh environment and execution order for the GPU cells, including authenticated/gated Llama weights and GPU memory.
3. Map all output CSVs to their generating cells and compare hashes or row-level predictions after a fresh run.
4. Confirm image access, licensing and human-response privacy in the public datasets.
5. Confirm the statistical scripts' output matches each published table, including the selected nine contrastive prompt comparisons, the five generative prompt comparisons and fifteen main architecture comparisons (different Holm correction families must not be conflated).

No claim of fresh GPU execution is made by this release.
