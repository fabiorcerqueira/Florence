# VISAPP FPD-181 — consolidation and submission audit

This is a **candidate supplementary release**, not proof of fresh GPU inference.

## Reproduction

Install: `python -m pip install pandas numpy scipy scikit-learn statsmodels`

From this directory run: `python verify_release.py`, `python reproduce.py`, `python reproduce_extended.py`, and `python reproduce_paired_tests.py`. The last script writes the **exact 15/9/12 Holm correction families** used in the paper to `results/`; the extended script explores different correction families. Do not substitute adjusted p-values between these families.

## Verification in this packaging session

- `verify_release.py`: PASS
- `reproduce_paired_tests.py`: PASS
- Source manuscript LaTeX text checked for identifying strings (limited static scan): acknowledg
- Statistical CSVs compared byte-for-byte with the previously verified 15/9/12 outputs.

## Double-blind and distribution cautions

The manuscript uses anonymous authors and does not display direct GitHub URLs. However, **the original notebook, filenames, outputs, notebook metadata, and README contain identifying GitHub accounts and possibly personal information**. Thus this full candidate release must **NOT** be uploaded unchanged to a double-blind review system. For review, supply only anonymized data and scripts, and audit metadata, comments, image source attribution and indirect identifiers. Restore public code links after the review phase according to conference rules.

The original notebook is kept intact for archival fidelity, not anonymized. No image redistribution permissions, human-annotation privacy clearance, fresh model inference, or immutable checkpoint revisions were independently verified.
